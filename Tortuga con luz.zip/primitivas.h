/* 
 * File:   primitivas.h
 * Author: Camilo José Cruz Rivera 1428907
 * Author: Erik López Pacheco 1430406
 * Author: Jesús Alberto Ramírez Otálvaro 1422554
 *
 * Created on 17 de Abril del 2018, 15:05
 */
//

void DrawAxis(void);
void drawSphereTurtle();
void Draw_Parallel (float *At);
void Draw_Meridian (float *At);
void Draw_Vector(float *At, float *Direction);
